#ifndef CONJUNTO_H
#define CONJUNTO_H

typedef struct conjunto Conjunto;
//Cria um conjunto com uma quantidade inicial de vagas
Conjunto* conjuntoCreate(int);
//Tenta inserir um item inteiro no conjunto
int conjuntoInsert(Conjunto*, int);

void conjuntoPrint(Conjunto*);

Conjunto* conjuntoRemove(Conjunto*, int);

Conjunto* conjuntoIntersec(Conjunto*, Conjunto*, Conjunto*);
void conjuntoDiferença();

void conjuntoUniao();

void Maior();

void Menor();

void iguais();

void tamanho();

void conjuntoVazio();

#endif