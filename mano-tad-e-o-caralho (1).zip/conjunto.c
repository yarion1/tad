#include <stdio.h>
#include <stdlib.h>
#include "conjunto.h"

struct conjunto{
  int tam, qtde, *vetor;
};

Conjunto* conjuntoCreate(int tam){
  Conjunto* copyConj = (Conjunto*)malloc(sizeof(Conjunto*));
  if(copyConj != NULL){
    copyConj->vetor = (int*) calloc(sizeof(int), tam);
    copyConj->tam = tam; //tamanho do conjunto (espaços)
    copyConj->qtde = 0;//conjunto começa vazio
  }
  return copyConj;
}
//Busca o item no vetor de dados.
int conjuntoSearch(Conjunto* set, int item){
  int i;
  for(i=set->qtde-1; i>=0; i--)
    if (set->vetor[i]==item)
      break;
  return i;
}

int conjuntoInsert(Conjunto* copyConj, int item){
    if(conjuntoSearch(copyConj, item)<0){ //Nao encontrei o item no conjunto
      if(copyConj->qtde>=copyConj->tam)
        copyConj->vetor = (int*)realloc(copyConj->vetor, copyConj->tam+1);
      if(copyConj->vetor== NULL) 
        return 0;
      copyConj->tam++;
      copyConj->vetor[copyConj->qtde++] = item; 
      return 1;
    }
  return 0;
}

Conjunto* conjuntoRemove(Conjunto* copyConj, int item){

  int j=0;
  int k = conjuntoSearch(copyConj, item);
    if(k>0){
      for(j = k ; j < copyConj->qtde; j++){
        copyConj->vetor[j] = copyConj->vetor[j+1];
      }
      copyConj->qtde--;
    } else{
      printf("\nO elemento selecionado para ser excluido não existe no vetor, retornando o conjunto completo:\n");
    }   
  return copyConj;
}

void conjuntoPrint(Conjunto* set){
  int i, res;
  putchar('{');
  
  for(i = 0; i < set->qtde; i++){
    printf("%d, ", set->vetor[i]);
  }
  putchar('}');
}

 Conjunto* conjuntoIntersec(Conjunto* conj1, Conjunto* conj2, Conjunto* conjGen){

   //Criem um conjunto novo e vazio (create)
   //Naveguem pelos itens de um conjunto (conj1)
   //Para cada item de conj1 procurem no conj2 usando a Busca
   //Caso encontrem, insiram este item no conjunto novo
   //Retorne o conjunto novo
   int i, item;

   for(i = 0; i< 15 ; i++){

     if(conjuntoSearch(conj1, conj2->vetor[i])>0){
       conjuntoInsert(conjGen, conj1->vetor[i]);
     }
   }
   return conjGen;
}